UPDATE product
SET standard_price = 5400.00
where product_description = 'Sofabed';

SELECT * FROM product