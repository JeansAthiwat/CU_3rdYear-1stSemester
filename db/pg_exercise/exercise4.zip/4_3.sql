SELECT order_id , order_date
FROM ordert
WHERE ordert.customer_id = '10001'