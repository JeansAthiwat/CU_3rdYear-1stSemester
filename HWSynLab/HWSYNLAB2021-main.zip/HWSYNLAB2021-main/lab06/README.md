# ขอขอบคุณ
* aqover - VGA
* tongplw - UART