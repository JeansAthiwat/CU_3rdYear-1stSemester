# HWSYNLAB2021
For HW-SYN-LAB Computer Engineering, Chulalongkorn University

Educational purposes only.

## Big thanks to
* https://github.com/aqover/HW-Lab
* https://github.com/tongplw/HW-Syn-Lab
